# Global replicator instance
replicator = None

from .routes import get_db_conn
