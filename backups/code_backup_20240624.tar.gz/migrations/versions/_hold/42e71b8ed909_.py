"""empty message

Revision ID: 42e71b8ed909
Revises: a0f03c65e42f, update_workflow_stages
Create Date: 2025-04-24 14:24:14.368379

"""

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = "42e71b8ed909"
down_revision = "update_workflow_stages"
branch_labels = None
depends_on = None


def upgrade():
    pass


def downgrade():
    pass
